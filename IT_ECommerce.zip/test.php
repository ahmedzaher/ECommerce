
<?php
require_once 'DBController.php';
require_once './Controller.php';

    $c = new Controller();
    $c->getProducts2();
?>
