<?php  
    header("Location:  View/customer/shopping.php");
?>